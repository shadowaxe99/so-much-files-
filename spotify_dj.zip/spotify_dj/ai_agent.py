import spotipy
from spotipy.oauth2 import SpotifyOAuth

sp = spotipy.Spotify(auth_manager=SpotifyOAuth(client_id='your_client_id',client_secret='your_client_secret',redirect_uri='http://localhost:8888/callback',scope='user-read-playback-state,user-modify-playback-state'))

def play_music():
    sp.start_playback()

def pause_music():
    sp.pause_playback()

def create_playlist(name):
    user_id = sp.current_user()['id']
    sp.user_playlist_create(user_id, name)